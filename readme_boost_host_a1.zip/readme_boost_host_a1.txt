link.jam: No such file or directory
Performing configuration checks

    - zlib                     : yes (cached)
    - lockfree boost::atomic_flag : yes (cached)

Component configuration:

    - atomic                   : not building
    - chrono                   : not building
    - context                  : not building
    - coroutine                : not building
    - date_time                : building
    - exception                : not building
    - filesystem               : building
    - graph                    : not building
    - graph_parallel           : not building
    - iostreams                : building
    - locale                   : not building
    - log                      : not building
    - math                     : not building
    - mpi                      : not building
    - program_options          : building
    - python                   : not building
    - random                   : not building
    - regex                    : not building
    - serialization            : building
    - signals                  : not building
    - system                   : not building
    - test                     : not building
    - thread                   : building
    - timer                    : not building
    - wave                     : not building

...patience...
...patience...
...found 1947 targets...
...updating 92 targets...
gcc.compile.c++ bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/greg_month.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_DATE_TIME_STATIC_LINK -DDATE_TIME_INLINE -DNDEBUG  -I"." -c -o "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/greg_month.o" "libs/date_time/src/gregorian/greg_month.cpp"

In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/date_time/date_names_put.hpp:20,
                 from ./boost/date_time/date_formatting_locales.hpp:18,
                 from ./boost/date_time/gregorian/greg_facet.hpp:13,
                 from libs/date_time/src/gregorian/greg_month.cpp:15:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/mpl/lambda_fwd.hpp:23,
                 from ./boost/mpl/aux_/na_spec.hpp:18,
                 from ./boost/mpl/if.hpp:19,
                 from ./boost/date_time/constrained_value.hpp:16,
                 from ./boost/date_time/gregorian/greg_month.hpp:12,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/date_time/gregorian/parsers.hpp:13,
                 from ./boost/date_time/gregorian/greg_facet.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:15:
./boost/date_time/date_parsing.hpp: In function ‘date_type boost::date_time::parse_date(const string&, int)’:
./boost/date_time/date_parsing.hpp:116:45: warning: typedef ‘year_type’ locally defined but not used [-Wunused-local-typedefs]
  116 |       typedef typename date_type::year_type year_type;
      |                                             ^~~~~~~~~
./boost/date_time/date_parsing.hpp: In function ‘date_type boost::date_time::parse_undelimited_date(const string&)’:
./boost/date_time/date_parsing.hpp:163:45: warning: typedef ‘year_type’ locally defined but not used [-Wunused-local-typedefs]
  163 |       typedef typename date_type::year_type year_type;
      |                                             ^~~~~~~~~
In file included from libs/date_time/src/gregorian/greg_month.cpp:15:
./boost/date_time/gregorian/greg_facet.hpp: In function ‘std::basic_istream<charT>& boost::gregorian::operator>>(std::basic_istream<charT>&, boost::gregorian::date&)’:
./boost/date_time/gregorian/greg_facet.hpp:218:76: warning: typedef ‘facet_def’ locally defined but not used [-Wunused-local-typedefs]
  218 |     typedef boost::date_time::all_date_names_put<greg_facet_config, charT> facet_def;
      |                                                                            ^~~~~~~~~
./boost/date_time/gregorian/greg_facet.hpp: In function ‘std::basic_istream<charT>& boost::gregorian::operator>>(std::basic_istream<charT>&, boost::gregorian::greg_month&)’:
./boost/date_time/gregorian/greg_facet.hpp:295:12: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  295 |       std::auto_ptr< const facet_def > f(create_facet_def(a));
      |            ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from libs/date_time/src/gregorian/greg_month.cpp:15:
./boost/date_time/gregorian/greg_facet.hpp: In function ‘std::basic_istream<charT>& boost::gregorian::operator>>(std::basic_istream<charT>&, boost::gregorian::greg_weekday&)’:
./boost/date_time/gregorian/greg_facet.hpp:337:12: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  337 |       std::auto_ptr< const facet_def > f(create_facet_def(a));
      |            ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_month.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/greg_weekday.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_DATE_TIME_STATIC_LINK -DDATE_TIME_INLINE -DNDEBUG  -I"." -c -o "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/greg_weekday.o" "libs/date_time/src/gregorian/greg_weekday.cpp"

In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/gregorian/greg_month.hpp:14,
                 from libs/date_time/src/gregorian/greg_names.hpp:14,
                 from libs/date_time/src/gregorian/greg_weekday.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/date_generators.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_DATE_TIME_STATIC_LINK -DDATE_TIME_INLINE -DNDEBUG  -I"." -c -o "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/date_generators.o" "libs/date_time/src/gregorian/date_generators.cpp"

RmTemps bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/libboost_date_time.a(clean)

    rm -f "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/libboost_date_time.a" 

gcc.archive bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/libboost_date_time.a

    "/usr/bin/ar"  rc "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/libboost_date_time.a" "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/greg_month.o" "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/greg_weekday.o" "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/gregorian/date_generators.o"
    "/usr/bin/ranlib" "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/libboost_date_time.a"

common.copy stage/lib/libboost_date_time.a

    cp "bin.v2/libs/date_time/build/gcc-9/release/link-static/threading-multi/libboost_date_time.a"  "stage/lib/libboost_date_time.a"

gcc.compile.c++ bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/error_code.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/error_code.o" "libs/system/src/error_code.cpp"

RmTemps bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/libboost_system.a(clean)

    rm -f "bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/libboost_system.a" 

gcc.archive bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/libboost_system.a

    "/usr/bin/ar"  rc "bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/libboost_system.a" "bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/error_code.o"
    "/usr/bin/ranlib" "bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/libboost_system.a"

common.copy stage/lib/libboost_system.a

    cp "bin.v2/libs/system/build/gcc-9/release/link-static/threading-multi/libboost_system.a"  "stage/lib/libboost_system.a"

gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/codecvt_error_category.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/codecvt_error_category.o" "libs/filesystem/src/codecvt_error_category.cpp"

gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/operations.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/operations.o" "libs/filesystem/src/operations.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/filesystem/path.hpp:28,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
libs/filesystem/src/operations.cpp: In function ‘int {anonymous}::readdir_r_simulator(DIR*, dirent*, dirent**)’:
libs/filesystem/src/operations.cpp:1959:18: warning: ‘int readdir_r(DIR*, dirent*, dirent**)’ is deprecated [-Wdeprecated-declarations]
 1959 |       { return ::readdir_r(dirp, entry, result); }
      |                  ^~~~~~~~~
In file included from /usr/include/features.h:461,
                 from /usr/include/x86_64-linux-gnu/c++/9/bits/os_defines.h:39,
                 from /usr/include/x86_64-linux-gnu/c++/9/bits/c++config.h:528,
                 from /usr/include/c++/9/cstddef:49,
                 from ./boost/config/select_stdlib_config.hpp:18,
                 from ./boost/config.hpp:40,
                 from ./boost/filesystem/operations.hpp:18,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/dirent.h:189:12: note: declared here
  189 | extern int __REDIRECT (readdir_r,
      |            ^~~~~~~~~~
libs/filesystem/src/operations.cpp:1959:47: warning: ‘int readdir_r(DIR*, dirent*, dirent**)’ is deprecated [-Wdeprecated-declarations]
 1959 |       { return ::readdir_r(dirp, entry, result); }
      |                                               ^
In file included from /usr/include/features.h:461,
                 from /usr/include/x86_64-linux-gnu/c++/9/bits/os_defines.h:39,
                 from /usr/include/x86_64-linux-gnu/c++/9/bits/c++config.h:528,
                 from /usr/include/c++/9/cstddef:49,
                 from ./boost/config/select_stdlib_config.hpp:18,
                 from ./boost/config.hpp:40,
                 from ./boost/filesystem/operations.hpp:18,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/dirent.h:189:12: note: declared here
  189 | extern int __REDIRECT (readdir_r,
      |            ^~~~~~~~~~
libs/filesystem/src/operations.cpp:1959:47: warning: ‘int readdir_r(DIR*, dirent*, dirent**)’ is deprecated [-Wdeprecated-declarations]
 1959 |       { return ::readdir_r(dirp, entry, result); }
      |                                               ^
In file included from /usr/include/features.h:461,
                 from /usr/include/x86_64-linux-gnu/c++/9/bits/os_defines.h:39,
                 from /usr/include/x86_64-linux-gnu/c++/9/bits/c++config.h:528,
                 from /usr/include/c++/9/cstddef:49,
                 from ./boost/config/select_stdlib_config.hpp:18,
                 from ./boost/config.hpp:40,
                 from ./boost/filesystem/operations.hpp:18,
                 from libs/filesystem/src/operations.cpp:44:
/usr/include/dirent.h:189:12: note: declared here
  189 | extern int __REDIRECT (readdir_r,
      |            ^~~~~~~~~~
libs/filesystem/src/operations.cpp: At global scope:
libs/filesystem/src/operations.cpp:323:8: warning: ‘bool {anonymous}::error(bool, const boost::system::error_code&, const boost::filesystem::path&, const boost::filesystem::path&, boost::system::error_code*, const string&)’ defined but not used [-Wunused-function]
  323 |   bool error(bool was_error, const error_code& result,
      |        ^~~~~
gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/path.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/path.o" "libs/filesystem/src/path.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/filesystem/path.hpp:28,
                 from libs/filesystem/src/path.cpp:26:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/path.cpp:26:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/path.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/path_traits.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/path_traits.o" "libs/filesystem/src/path_traits.cpp"

gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/portability.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/portability.o" "libs/filesystem/src/portability.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/filesystem/path.hpp:28,
                 from libs/filesystem/src/portability.cpp:21:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from libs/filesystem/src/portability.cpp:21:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from libs/filesystem/src/portability.cpp:21:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/unique_path.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/unique_path.o" "libs/filesystem/src/unique_path.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/filesystem/path.hpp:28,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/filesystem/path.hpp:29,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/filesystem/path_traits.hpp:29,
                 from ./boost/filesystem/path.hpp:25,
                 from ./boost/filesystem/operations.hpp:25,
                 from libs/filesystem/src/unique_path.cpp:20:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o" "libs/filesystem/src/utf8_codecvt_facet.cpp"

gcc.compile.c++ bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/windows_file_codecvt.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_FILESYSTEM_STATIC_LINK=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/windows_file_codecvt.o" "libs/filesystem/src/windows_file_codecvt.cpp"

RmTemps bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/libboost_filesystem.a(clean)

    rm -f "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/libboost_filesystem.a" 

gcc.archive bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/libboost_filesystem.a

    "/usr/bin/ar"  rc "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/libboost_filesystem.a" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/codecvt_error_category.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/operations.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/path.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/path_traits.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/portability.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/unique_path.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/windows_file_codecvt.o"
    "/usr/bin/ranlib" "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/libboost_filesystem.a"

common.copy stage/lib/libboost_filesystem.a

    cp "bin.v2/libs/filesystem/build/gcc-9/release/link-static/threading-multi/libboost_filesystem.a"  "stage/lib/libboost_filesystem.a"

gcc.compile.c++ bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/file_descriptor.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_IOSTREAMS_USE_DEPRECATED -DNDEBUG  -I"." -c -o "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/file_descriptor.o" "libs/iostreams/src/file_descriptor.cpp"

In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/file_descriptor.hpp:28,
                 from libs/iostreams/src/file_descriptor.cpp:23:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/device/file_descriptor.hpp:27,
                 from libs/iostreams/src/file_descriptor.cpp:23:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/mapped_file.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_IOSTREAMS_USE_DEPRECATED -DNDEBUG  -I"." -c -o "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/mapped_file.o" "libs/iostreams/src/mapped_file.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/range/iterator_range_core.hpp:23,
                 from ./boost/range/iterator_range.hpp:13,
                 from ./boost/iostreams/traits.hpp:39,
                 from ./boost/iostreams/detail/dispatch.hpp:17,
                 from ./boost/iostreams/flush.hpp:17,
                 from ./boost/iostreams/close.hpp:18,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/bool_trait_def.hpp:14,
                 from ./boost/type_traits/is_same.hpp:31,
                 from ./boost/type_traits/intrinsics.hpp:205,
                 from ./boost/type_traits/is_base_and_derived.hpp:12,
                 from ./boost/iostreams/detail/select.hpp:32,
                 from ./boost/iostreams/detail/dispatch.hpp:16,
                 from ./boost/iostreams/flush.hpp:17,
                 from ./boost/iostreams/close.hpp:18,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/device/mapped_file.hpp:29,
                 from libs/iostreams/src/mapped_file.cpp:18:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/iostreams/detail/config/codecvt.hpp:62,
                 from ./boost/iostreams/positioning.hpp:21,
                 from ./boost/iostreams/seek.hpp:23,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:13,
                 from ./boost/iostreams/close.hpp:19,
                 from ./boost/iostreams/device/mapped_file.hpp:20,
                 from libs/iostreams/src/mapped_file.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/bzip2.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_IOSTREAMS_USE_DEPRECATED -DNDEBUG  -I"." -c -o "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/bzip2.o" "libs/iostreams/src/bzip2.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/range/iterator_range_core.hpp:23,
                 from ./boost/range/iterator_range.hpp:13,
                 from ./boost/iostreams/traits.hpp:39,
                 from ./boost/iostreams/detail/dispatch.hpp:17,
                 from ./boost/iostreams/read.hpp:19,
                 from ./boost/iostreams/detail/buffer.hpp:20,
                 from ./boost/iostreams/filter/symmetric.hpp:49,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/bool_trait_def.hpp:14,
                 from ./boost/type_traits/is_same.hpp:31,
                 from ./boost/type_traits/intrinsics.hpp:205,
                 from ./boost/type_traits/is_base_and_derived.hpp:12,
                 from ./boost/iostreams/detail/select.hpp:32,
                 from ./boost/iostreams/detail/dispatch.hpp:16,
                 from ./boost/iostreams/read.hpp:19,
                 from ./boost/iostreams/detail/buffer.hpp:20,
                 from ./boost/iostreams/filter/symmetric.hpp:49,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/bzip2.hpp:29,
                 from libs/iostreams/src/bzip2.cpp:19:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/bzip2.hpp:19,
                 from libs/iostreams/src/bzip2.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/gzip.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_IOSTREAMS_USE_DEPRECATED -DNDEBUG  -I"." -c -o "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/gzip.o" "libs/iostreams/src/gzip.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/range/iterator_range_core.hpp:23,
                 from ./boost/range/iterator_range.hpp:13,
                 from ./boost/iostreams/traits.hpp:39,
                 from ./boost/iostreams/detail/dispatch.hpp:17,
                 from ./boost/iostreams/read.hpp:19,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:12,
                 from ./boost/iostreams/filter/gzip.hpp:31,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/bool_trait_def.hpp:14,
                 from ./boost/type_traits/is_same.hpp:31,
                 from ./boost/type_traits/intrinsics.hpp:205,
                 from ./boost/type_traits/is_base_and_derived.hpp:12,
                 from ./boost/iostreams/detail/select.hpp:32,
                 from ./boost/iostreams/detail/dispatch.hpp:16,
                 from ./boost/iostreams/read.hpp:19,
                 from ./boost/iostreams/detail/adapter/non_blocking_adapter.hpp:12,
                 from ./boost/iostreams/filter/gzip.hpp:31,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from ./boost/iostreams/filter/gzip.hpp:38,
                 from libs/iostreams/src/gzip.cpp:18:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/gzip.hpp:26,
                 from libs/iostreams/src/gzip.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/zlib.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DBOOST_IOSTREAMS_USE_DEPRECATED -DNDEBUG  -I"." -c -o "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/zlib.o" "libs/iostreams/src/zlib.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/range/iterator_range_core.hpp:23,
                 from ./boost/range/iterator_range.hpp:13,
                 from ./boost/iostreams/traits.hpp:39,
                 from ./boost/iostreams/detail/dispatch.hpp:17,
                 from ./boost/iostreams/read.hpp:19,
                 from ./boost/iostreams/detail/buffer.hpp:20,
                 from ./boost/iostreams/filter/symmetric.hpp:49,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/bool_trait_def.hpp:14,
                 from ./boost/type_traits/is_same.hpp:31,
                 from ./boost/type_traits/intrinsics.hpp:205,
                 from ./boost/type_traits/is_base_and_derived.hpp:12,
                 from ./boost/iostreams/detail/select.hpp:32,
                 from ./boost/iostreams/detail/dispatch.hpp:16,
                 from ./boost/iostreams/read.hpp:19,
                 from ./boost/iostreams/detail/buffer.hpp:20,
                 from ./boost/iostreams/filter/symmetric.hpp:49,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/iostreams/filter/symmetric.hpp:60,
                 from ./boost/iostreams/filter/zlib.hpp:31,
                 from libs/iostreams/src/zlib.cpp:19:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/iostreams/filter/zlib.hpp:20,
                 from libs/iostreams/src/zlib.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
RmTemps bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/libboost_iostreams.a(clean)

    rm -f "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/libboost_iostreams.a" 

gcc.archive bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/libboost_iostreams.a

    "/usr/bin/ar"  rc "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/libboost_iostreams.a" "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/file_descriptor.o" "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/mapped_file.o" "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/bzip2.o" "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/gzip.o" "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/zlib.o"
    "/usr/bin/ranlib" "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/libboost_iostreams.a"

common.copy stage/lib/libboost_iostreams.a

    cp "bin.v2/libs/iostreams/build/gcc-9/release/link-static/threading-multi/libboost_iostreams.a"  "stage/lib/libboost_iostreams.a"

gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/cmdline.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/cmdline.o" "libs/program_options/src/cmdline.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/bind/bind.hpp:29,
                 from ./boost/bind.hpp:22,
                 from libs/program_options/src/cmdline.cpp:18:
./boost/bind/arg.hpp: In constructor ‘boost::arg<I>::arg(const T&)’:
./boost/bind/arg.hpp:37:22: warning: typedef ‘T_must_be_placeholder’ locally defined but not used [-Wunused-local-typedefs]
   37 |         typedef char T_must_be_placeholder[ I == is_placeholder<T>::value? 1: -1 ];
      |                      ^~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/function/function_template.hpp: In instantiation of ‘void boost::detail::function::basic_vtable1<R, T0>::assign_functor(FunctionObj, boost::detail::function::function_buffer&, mpl_::true_) const [with FunctionObj = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&; mpl_::true_ = mpl_::bool_<true>]’:
./boost/function/function_template.hpp:602:13:   required from ‘bool boost::detail::function::basic_vtable1<R, T0>::assign_to(FunctionObj, boost::detail::function::function_buffer&, boost::detail::function::function_obj_tag) const [with FunctionObj = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&]’
./boost/function/function_template.hpp:492:45:   required from ‘bool boost::detail::function::basic_vtable1<R, T0>::assign_to(F, boost::detail::function::function_buffer&) const [with F = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&]’
./boost/function/function_template.hpp:936:7:   required from ‘void boost::function1<R, T1>::assign_to(Functor) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&]’
./boost/function/function_template.hpp:722:7:   required from ‘boost::function1<R, T1>::function1(Functor, typename boost::enable_if_c<boost::type_traits::ice_not<boost::is_integral<Functor>::value>::value, int>::type) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&; typename boost::enable_if_c<boost::type_traits::ice_not<boost::is_integral<Functor>::value>::value, int>::type = int]’
libs/program_options/src/cmdline.cpp:227:74:   required from here
./boost/function/function_template.hpp:566:49: warning: placement new constructing an object of type ‘boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >’ and size ‘24’ in a region of type ‘char’ and size ‘1’ [-Wplacement-new=]
  566 |           new (reinterpret_cast<void*>(&functor.data)) FunctionObj(f);
      |                                         ~~~~~~~~^~~~
In file included from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/cmdline.cpp:11:
./boost/function/function_base.hpp: In instantiation of ‘static void boost::detail::function::functor_manager_common<Functor>::manage_small(const boost::detail::function::function_buffer&, boost::detail::function::function_buffer&, boost::detail::function::functor_manager_operation_type) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >]’:
./boost/function/function_base.hpp:364:56:   required from ‘static void boost::detail::function::functor_manager<Functor>::manager(const boost::detail::function::function_buffer&, boost::detail::function::function_buffer&, boost::detail::function::functor_manager_operation_type, mpl_::true_) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; mpl_::true_ = mpl_::bool_<true>]’
./boost/function/function_base.hpp:412:18:   required from ‘static void boost::detail::function::functor_manager<Functor>::manager(const boost::detail::function::function_buffer&, boost::detail::function::function_buffer&, boost::detail::function::functor_manager_operation_type, boost::detail::function::function_obj_tag) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >]’
./boost/function/function_base.hpp:440:20:   required from ‘static void boost::detail::function::functor_manager<Functor>::manage(const boost::detail::function::function_buffer&, boost::detail::function::function_buffer&, boost::detail::function::functor_manager_operation_type) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >]’
./boost/function/function_template.hpp:934:13:   required from ‘void boost::function1<R, T1>::assign_to(Functor) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&]’
./boost/function/function_template.hpp:722:7:   required from ‘boost::function1<R, T1>::function1(Functor, typename boost::enable_if_c<boost::type_traits::ice_not<boost::is_integral<Functor>::value>::value, int>::type) [with Functor = boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >; R = std::vector<boost::program_options::basic_option<char> >; T0 = std::vector<std::__cxx11::basic_string<char> >&; typename boost::enable_if_c<boost::type_traits::ice_not<boost::is_integral<Functor>::value>::value, int>::type = int]’
libs/program_options/src/cmdline.cpp:227:74:   required from here
./boost/function/function_base.hpp:318:54: warning: placement new constructing an object of type ‘boost::detail::function::functor_manager_common<boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > > >::functor_type’ {aka ‘boost::_bi::bind_t<std::vector<boost::program_options::basic_option<char> >, boost::_mfi::mf1<std::vector<boost::program_options::basic_option<char> >, boost::program_options::detail::cmdline, std::vector<std::__cxx11::basic_string<char> >&>, boost::_bi::list2<boost::_bi::value<boost::program_options::detail::cmdline*>, boost::arg<1> > >’} and size ‘24’ in a region of type ‘char’ and size ‘1’ [-Wplacement-new=]
  318 |             new (reinterpret_cast<void*>(&out_buffer.data)) functor_type(*in_functor);
      |                                           ~~~~~~~~~~~^~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/config_file.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/config_file.o" "libs/program_options/src/config_file.cpp"

In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/detail/facade_iterator_category.hpp:7,
                 from ./boost/iterator/iterator_facade.hpp:14,
                 from ./boost/program_options/eof_iterator.hpp:9,
                 from ./boost/program_options/detail/config_file.hpp:17,
                 from libs/program_options/src/config_file.cpp:10:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:28,
                 from libs/program_options/src/config_file.cpp:10:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/program_options/detail/convert.hpp:17,
                 from ./boost/program_options/detail/config_file.hpp:20,
                 from libs/program_options/src/config_file.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/options_description.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/options_description.o" "libs/program_options/src/options_description.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from libs/program_options/src/options_description.cpp:10:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from libs/program_options/src/options_description.cpp:10:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/parsers.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/parsers.o" "libs/program_options/src/parsers.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/parsers.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/bind/bind.hpp:29,
                 from ./boost/bind.hpp:22,
                 from libs/program_options/src/parsers.cpp:19:
./boost/bind/arg.hpp: In constructor ‘boost::arg<I>::arg(const T&)’:
./boost/bind/arg.hpp:37:22: warning: typedef ‘T_must_be_placeholder’ locally defined but not used [-Wunused-local-typedefs]
   37 |         typedef char T_must_be_placeholder[ I == is_placeholder<T>::value? 1: -1 ];
      |                      ^~~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/variables_map.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/variables_map.o" "libs/program_options/src/variables_map.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/variables_map.cpp:9:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/value_semantic.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/value_semantic.o" "libs/program_options/src/value_semantic.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:8:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from libs/program_options/src/value_semantic.cpp:8:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from libs/program_options/src/value_semantic.cpp:10:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from libs/program_options/src/value_semantic.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/positional_options.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/positional_options.o" "libs/program_options/src/positional_options.cpp"

gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o" "libs/program_options/src/utf8_codecvt_facet.cpp"

gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/convert.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/convert.o" "libs/program_options/src/convert.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/bind/bind.hpp:26,
                 from ./boost/bind.hpp:22,
                 from libs/program_options/src/convert.cpp:22:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from libs/program_options/src/convert.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/bind/bind.hpp:29,
                 from ./boost/bind.hpp:22,
                 from libs/program_options/src/convert.cpp:22:
./boost/bind/arg.hpp: In constructor ‘boost::arg<I>::arg(const T&)’:
./boost/bind/arg.hpp:37:22: warning: typedef ‘T_must_be_placeholder’ locally defined but not used [-Wunused-local-typedefs]
   37 |         typedef char T_must_be_placeholder[ I == is_placeholder<T>::value? 1: -1 ];
      |                      ^~~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/winmain.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/winmain.o" "libs/program_options/src/winmain.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/winmain.cpp:7:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/split.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/split.o" "libs/program_options/src/split.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/mpl/apply.hpp:24,
                 from ./boost/mpl/aux_/iter_apply.hpp:17,
                 from ./boost/mpl/aux_/find_if_pred.hpp:14,
                 from ./boost/mpl/find_if.hpp:17,
                 from ./boost/mpl/find.hpp:17,
                 from ./boost/mpl/aux_/contains_impl.hpp:20,
                 from ./boost/mpl/contains.hpp:20,
                 from ./boost/math/policies/policy.hpp:10,
                 from ./boost/math/special_functions/math_fwd.hpp:28,
                 from ./boost/math/special_functions/sign.hpp:17,
                 from ./boost/lexical_cast.hpp:167,
                 from ./boost/program_options/value_semantic.hpp:14,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/mpl/aux_/integral_wrapper.hpp:22,
                 from ./boost/mpl/int.hpp:20,
                 from ./boost/type_traits/detail/template_arity_spec.hpp:10,
                 from ./boost/type_traits/detail/type_trait_def.hpp:14,
                 from ./boost/type_traits/remove_reference.hpp:21,
                 from ./boost/any.hpp:21,
                 from ./boost/program_options/value_semantic.hpp:12,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/concept_check.hpp: In function ‘void boost::function_requires(Model*)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check45’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:45:7: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   45 |       BOOST_CONCEPT_ASSERT((Model));
      |       ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableGenerator<Func, Return>::~AdaptableGenerator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check453’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:453:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  453 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableUnaryFunction<Func, Return, Arg>::~AdaptableUnaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check465’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:465:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  465 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check466’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:466:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  466 |           BOOST_CONCEPT_ASSERT((Convertible<Arg, argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AdaptableBinaryFunction<Func, Return, First, Second>::~AdaptableBinaryFunction()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check484’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:484:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  484 |           BOOST_CONCEPT_ASSERT((Convertible<result_type, Return>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check485’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:485:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  485 |           BOOST_CONCEPT_ASSERT((Convertible<First, first_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check486’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:486:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  486 |           BOOST_CONCEPT_ASSERT((Convertible<Second, second_argument_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::InputIterator<TT>::~InputIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check517’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:517:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  517 |         BOOST_CONCEPT_ASSERT((SignedInteger<difference_type>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check518’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:518:9: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  518 |         BOOST_CONCEPT_ASSERT((Convertible<iterator_category, std::input_iterator_tag>));
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardIterator<TT>::~ForwardIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check548’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:548:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  548 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::BidirectionalIterator<TT>::~BidirectionalIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check576’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:576:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  576 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessIterator<TT>::~RandomAccessIterator()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check606’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:606:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  606 |           BOOST_CONCEPT_ASSERT((Convertible<
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Container<C>::~Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check653’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:653:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  653 |           BOOST_CONCEPT_ASSERT((InputIterator<const_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_Container<C>::~Mutable_Container()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check680’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:680:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  680 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check683’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:683:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  683 |           BOOST_CONCEPT_ASSERT((InputIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ForwardContainer<C>::~ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check700’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:700:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  700 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ForwardContainer<C>::~Mutable_ForwardContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check713’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:713:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  713 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::ReversibleContainer<C>::~ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check729’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:729:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  729 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check733’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:733:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  733 |           BOOST_CONCEPT_ASSERT((BidirectionalIterator<const_reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_ReversibleContainer<C>::~Mutable_ReversibleContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check755’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:755:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  755 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check756’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:756:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  756 |           BOOST_CONCEPT_ASSERT((Mutable_BidirectionalIterator<reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::RandomAccessContainer<C>::~RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check773’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:773:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  773 |           BOOST_CONCEPT_ASSERT((
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::Mutable_RandomAccessContainer<C>::~Mutable_RandomAccessContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check800’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:800:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  800 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check801’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:801:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  801 |           BOOST_CONCEPT_ASSERT((Mutable_RandomAccessIterator<typename self::reverse_iterator>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp: In destructor ‘boost::AssociativeContainer<C>::~AssociativeContainer()’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check905’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:905:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  905 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<key_compare,key_type,key_type>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check908’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/concept_check.hpp:908:11: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
  908 |           BOOST_CONCEPT_ASSERT((BinaryPredicate<value_compare,value_type_,value_type_>));
      |           ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check172’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:172:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  172 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check173’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:173:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  173 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp: In function ‘bool boost::range::equal(const SinglePassRange1&, const SinglePassRange2&, BinaryPredicate)’:
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check185’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:185:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  185 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange1> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
./boost/concept/detail/general.hpp:71:20: warning: typedef ‘boost_concept_check186’ locally defined but not used [-Wunused-local-typedefs]
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |                    ^~~~~~~~~~~~~~~~~~~
./boost/preprocessor/cat.hpp:29:34: note: in definition of macro ‘BOOST_PP_CAT_I’
   29 | #    define BOOST_PP_CAT_I(a, b) a ## b
      |                                  ^
./boost/concept/detail/general.hpp:71:7: note: in expansion of macro ‘BOOST_PP_CAT’
   71 |       BOOST_PP_CAT(boost_concept_check,__LINE__)
      |       ^~~~~~~~~~~~
./boost/concept/assert.hpp:44:5: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT_FN’
   44 |     BOOST_CONCEPT_ASSERT_FN(void(*)ModelInParens)
      |     ^~~~~~~~~~~~~~~~~~~~~~~
./boost/range/concepts.hpp:92:45: note: in expansion of macro ‘BOOST_CONCEPT_ASSERT’
   92 |     #define BOOST_RANGE_CONCEPT_ASSERT( x ) BOOST_CONCEPT_ASSERT( x )
      |                                             ^~~~~~~~~~~~~~~~~~~~
./boost/range/algorithm/equal.hpp:186:13: note: in expansion of macro ‘BOOST_RANGE_CONCEPT_ASSERT’
  186 |             BOOST_RANGE_CONCEPT_ASSERT(( SinglePassRangeConcept<const SinglePassRange2> ));
      |             ^~~~~~~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/program_options/options_description.hpp:16,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/function/function_base.hpp:16,
                 from ./boost/function/detail/prologue.hpp:17,
                 from ./boost/function/function_template.hpp:13,
                 from ./boost/function/detail/maybe_include.hpp:18,
                 from ./boost/function/function1.hpp:11,
                 from ./boost/program_options/value_semantic.hpp:13,
                 from ./boost/program_options/options_description.hpp:13,
                 from ./boost/program_options/detail/cmdline.hpp:14,
                 from ./boost/program_options/parsers.hpp:12,
                 from libs/program_options/src/split.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
RmTemps bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/libboost_program_options.a(clean)

    rm -f "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/libboost_program_options.a" 

gcc.archive bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/libboost_program_options.a

    "/usr/bin/ar"  rc "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/libboost_program_options.a" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/cmdline.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/config_file.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/options_description.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/parsers.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/variables_map.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/value_semantic.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/positional_options.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/convert.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/winmain.o" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/split.o"
    "/usr/bin/ranlib" "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/libboost_program_options.a"

common.copy stage/lib/libboost_program_options.a

    cp "bin.v2/libs/program_options/build/gcc-9/release/link-static/threading-multi/libboost_program_options.a"  "stage/lib/libboost_program_options.a"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_archive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_archive.o" "libs/serialization/src/basic_archive.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_iarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_iarchive.o" "libs/serialization/src/basic_iarchive.cpp"

libs/serialization/src/basic_iarchive.cpp: In member function ‘const boost::archive::detail::basic_pointer_iserializer* boost::archive::detail::basic_iarchive_impl::load_pointer(boost::archive::detail::basic_iarchive&, void*&, const boost::archive::detail::basic_pointer_iserializer*, const boost::archive::detail::basic_pointer_iserializer* (*)(const boost::serialization::extended_type_info&))’:
libs/serialization/src/basic_iarchive.cpp:455:23: warning: variable ‘new_cid’ set but not used [-Wunused-but-set-variable]
  455 |         class_id_type new_cid = register_type(bpis_ptr->get_basic_serializer());
      |                       ^~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_iserializer.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_iserializer.o" "libs/serialization/src/basic_iserializer.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_oarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_oarchive.o" "libs/serialization/src/basic_oarchive.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_oserializer.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_oserializer.o" "libs/serialization/src/basic_oserializer.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_pointer_iserializer.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_pointer_iserializer.o" "libs/serialization/src/basic_pointer_iserializer.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_pointer_oserializer.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_pointer_oserializer.o" "libs/serialization/src/basic_pointer_oserializer.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_serializer_map.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_serializer_map.o" "libs/serialization/src/basic_serializer_map.cpp"

libs/serialization/src/basic_serializer_map.cpp: In member function ‘bool boost::archive::detail::basic_serializer_map::insert(const boost::archive::detail::basic_serializer*)’:
libs/serialization/src/basic_serializer_map.cpp:46:47: warning: variable ‘result’ set but not used [-Wunused-but-set-variable]
   46 |     const std::pair<map_type::iterator, bool> result =
      |                                               ^~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_iprimitive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_iprimitive.o" "libs/serialization/src/basic_text_iprimitive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_iprimitive.hpp:48,
                 from ./boost/archive/impl/basic_text_iprimitive.ipp:24,
                 from libs/serialization/src/basic_text_iprimitive.cpp:19:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/impl/basic_text_iprimitive.ipp:24,
                 from libs/serialization/src/basic_text_iprimitive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/iterator_adaptor.hpp:14,
                 from ./boost/archive/iterators/remove_whitespace.hpp:25,
                 from ./boost/archive/impl/basic_text_iprimitive.ipp:28,
                 from libs/serialization/src/basic_text_iprimitive.cpp:19:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/archive/impl/basic_text_iprimitive.ipp:31,
                 from libs/serialization/src/basic_text_iprimitive.cpp:19:
./boost/archive/iterators/transform_width.hpp: In instantiation of ‘boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>::transform_width(const boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>&) [with Base = boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<char> >, char>; int BitsOut = 8; int BitsIn = 6; CharType = char]’:
./boost/archive/impl/basic_text_iprimitive.ipp:90:12:   required from ‘void boost::archive::basic_text_iprimitive<IStream>::load_binary(void*, std::size_t) [with IStream = std::basic_istream<char>; std::size_t = long unsigned int]’
libs/serialization/src/basic_text_iprimitive.cpp:25:16:   required from here
./boost/archive/iterators/transform_width.hpp:104:18: warning: ‘boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<char> >, char>, 8, 6, char>::m_remaining_bits’ will be initialized after [-Wreorder]
  104 |     unsigned int m_remaining_bits;
      |                  ^~~~~~~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:101:21: warning:   ‘boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<char> >, char>, 8, 6, char>::base_value_type boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<char> >, char>, 8, 6, char>::m_buffer_in’ [-Wreorder]
  101 |     base_value_type m_buffer_in;
      |                     ^~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:119:5: warning:   when initialized here [-Wreorder]
  119 |     transform_width(const transform_width & rhs) :
      |     ^~~~~~~~~~~~~~~
In file included from libs/serialization/src/basic_text_iprimitive.cpp:19:
./boost/archive/impl/basic_text_iprimitive.ipp:47:10: warning: ‘bool boost::archive::{anonymous}::is_whitespace(CharType) [with CharType = wchar_t]’ defined but not used [-Wunused-function]
   47 |     bool is_whitespace(wchar_t t){
      |          ^~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_oprimitive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_oprimitive.o" "libs/serialization/src/basic_text_oprimitive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_oprimitive.hpp:52,
                 from ./boost/archive/impl/basic_text_oprimitive.ipp:14,
                 from libs/serialization/src/basic_text_oprimitive.cpp:19:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from /usr/include/c++/9/iomanip:43,
                 from ./boost/archive/basic_text_oprimitive.hpp:27,
                 from ./boost/archive/impl/basic_text_oprimitive.ipp:14,
                 from libs/serialization/src/basic_text_oprimitive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/iterator_adaptor.hpp:14,
                 from ./boost/iterator/transform_iterator.hpp:12,
                 from ./boost/archive/iterators/base64_from_binary.hpp:31,
                 from ./boost/archive/impl/basic_text_oprimitive.ipp:18,
                 from libs/serialization/src/basic_text_oprimitive.cpp:19:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/archive/impl/basic_text_oprimitive.ipp:20,
                 from libs/serialization/src/basic_text_oprimitive.cpp:19:
./boost/archive/iterators/transform_width.hpp: In instantiation of ‘boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>::transform_width(const boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>&) [with Base = const char*; int BitsOut = 6; int BitsIn = 8; CharType = char]’:
./boost/archive/iterators/base64_from_binary.hpp:101:13:   required from ‘boost::archive::iterators::base64_from_binary<Base, CharType>::base64_from_binary(const boost::archive::iterators::base64_from_binary<Base, CharType>&) [with Base = boost::archive::iterators::transform_width<const char*, 6, 8>; CharType = char]’
./boost/iterator/iterator_adaptor.hpp:276:28:   required from ‘boost::iterator_adaptor<Derived, Base, Value, Traversal, Reference, Difference>::iterator_adaptor(const Base&) [with Derived = boost::archive::iterators::insert_linebreaks<boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<const char*, 6, 8> >, 76, const char>; Base = boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<const char*, 6, 8> >; Value = const char; Traversal = boost::single_pass_traversal_tag; Reference = const char; Difference = boost::use_default]’
./boost/archive/iterators/insert_linebreaks.hpp:88:18:   required from ‘boost::archive::iterators::insert_linebreaks<Base, N, CharType>::insert_linebreaks(T) [with T = const char*; Base = boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<const char*, 6, 8> >; int N = 76; CharType = const char]’
./boost/archive/impl/basic_text_oprimitive.ipp:61:9:   required from ‘void boost::archive::basic_text_oprimitive<OStream>::save_binary(const void*, std::size_t) [with OStream = std::basic_ostream<char>; std::size_t = long unsigned int]’
libs/serialization/src/basic_text_oprimitive.cpp:25:16:   required from here
./boost/archive/iterators/transform_width.hpp:104:18: warning: ‘boost::archive::iterators::transform_width<const char*, 6, 8>::m_remaining_bits’ will be initialized after [-Wreorder]
  104 |     unsigned int m_remaining_bits;
      |                  ^~~~~~~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:101:21: warning:   ‘boost::archive::iterators::transform_width<const char*, 6, 8>::base_value_type boost::archive::iterators::transform_width<const char*, 6, 8>::m_buffer_in’ [-Wreorder]
  101 |     base_value_type m_buffer_in;
      |                     ^~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:119:5: warning:   when initialized here [-Wreorder]
  119 |     transform_width(const transform_width & rhs) :
      |     ^~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_xml_archive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_xml_archive.o" "libs/serialization/src/basic_xml_archive.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/binary_iarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/binary_iarchive.o" "libs/serialization/src/binary_iarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_binary_iprimitive.hpp:47,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/archive/basic_binary_iprimitive.hpp:54,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/serialization/pfto.hpp:22,
                 from ./boost/archive/binary_iarchive_impl.hpp:20,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/binary_iarchive.hpp:63,
                 from libs/serialization/src/binary_iarchive.cpp:14:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_iprimitive.hpp:32,
                 from ./boost/archive/binary_iarchive_impl.hpp:21,
                 from ./boost/archive/binary_iarchive.hpp:20,
                 from libs/serialization/src/binary_iarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/binary_oarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/binary_oarchive.o" "libs/serialization/src/binary_oarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_binary_oprimitive.hpp:43,
                 from ./boost/archive/binary_oarchive_impl.hpp:22,
                 from ./boost/archive/binary_oarchive.hpp:21,
                 from libs/serialization/src/binary_oarchive.cpp:14:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_binary_oprimitive.hpp:28,
                 from ./boost/archive/binary_oarchive_impl.hpp:22,
                 from ./boost/archive/binary_oarchive.hpp:21,
                 from libs/serialization/src/binary_oarchive.cpp:14:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/archive/basic_binary_oprimitive.hpp:49,
                 from ./boost/archive/binary_oarchive_impl.hpp:22,
                 from ./boost/archive/binary_oarchive.hpp:21,
                 from libs/serialization/src/binary_oarchive.cpp:14:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/binary_oarchive.hpp:20,
                 from libs/serialization/src/binary_oarchive.cpp:14:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info.o" "libs/serialization/src/extended_type_info.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info_typeid.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info_typeid.o" "libs/serialization/src/extended_type_info_typeid.cpp"

In file included from ./boost/config.hpp:57,
                 from ./boost/detail/no_exceptions_support.hpp:66,
                 from libs/serialization/src/extended_type_info_typeid.cpp:18:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info_no_rtti.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info_no_rtti.o" "libs/serialization/src/extended_type_info_no_rtti.cpp"

In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/extended_type_info_no_rtti.cpp:16:
./boost/serialization/extended_type_info_no_rtti.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_no_rtti<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE116’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_no_rtti.hpp:116:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  116 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/polymorphic_iarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/polymorphic_iarchive.o" "libs/serialization/src/polymorphic_iarchive.cpp"

In file included from ./boost/config.hpp:57,
                 from ./boost/archive/detail/archive_serializer_map.hpp:23,
                 from libs/serialization/src/polymorphic_iarchive.cpp:16:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/iserializer.hpp:74,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/detail/archive_serializer_map.hpp:23,
                 from libs/serialization/src/polymorphic_iarchive.cpp:16:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/polymorphic_iarchive.hpp:162,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/archive/detail/iserializer.hpp:26,
                 from ./boost/archive/polymorphic_iarchive.hpp:33,
                 from libs/serialization/src/polymorphic_iarchive.cpp:19:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/polymorphic_oarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/polymorphic_oarchive.o" "libs/serialization/src/polymorphic_oarchive.cpp"

In file included from ./boost/config.hpp:57,
                 from ./boost/archive/detail/archive_serializer_map.hpp:23,
                 from libs/serialization/src/polymorphic_oarchive.cpp:16:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/oserializer.hpp:52,
                 from ./boost/archive/polymorphic_oarchive.hpp:32,
                 from libs/serialization/src/polymorphic_oarchive.cpp:19:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/detail/archive_serializer_map.hpp:23,
                 from libs/serialization/src/polymorphic_oarchive.cpp:16:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/stl_port.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/stl_port.o" "libs/serialization/src/stl_port.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_iarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_iarchive.o" "libs/serialization/src/text_iarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_iprimitive.hpp:48,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/text_iarchive.hpp:21,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/iserializer.hpp:74,
                 from ./boost/archive/detail/interface_iarchive.hpp:22,
                 from ./boost/archive/detail/common_iarchive.hpp:23,
                 from ./boost/archive/basic_text_iarchive.hpp:31,
                 from ./boost/archive/text_iarchive.hpp:24,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/text_iarchive.hpp:21,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/text_iarchive.hpp:124,
                 from libs/serialization/src/text_iarchive.cpp:16:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_iarchive.hpp:23,
                 from libs/serialization/src/text_iarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_oarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_oarchive.o" "libs/serialization/src/text_oarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_oprimitive.hpp:52,
                 from ./boost/archive/text_oarchive.hpp:30,
                 from libs/serialization/src/text_oarchive.cpp:16:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from /usr/include/c++/9/iomanip:43,
                 from ./boost/archive/basic_text_oprimitive.hpp:27,
                 from ./boost/archive/text_oarchive.hpp:30,
                 from libs/serialization/src/text_oarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/text_oarchive.hpp:22,
                 from libs/serialization/src/text_oarchive.cpp:16:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/oserializer.hpp:52,
                 from ./boost/archive/detail/interface_oarchive.hpp:23,
                 from ./boost/archive/detail/common_oarchive.hpp:22,
                 from ./boost/archive/basic_text_oarchive.hpp:32,
                 from ./boost/archive/text_oarchive.hpp:31,
                 from libs/serialization/src/text_oarchive.cpp:16:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/text_oarchive.hpp:22,
                 from libs/serialization/src/text_oarchive.cpp:16:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/void_cast.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/void_cast.o" "libs/serialization/src/void_cast.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/archive_exception.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/archive_exception.o" "libs/serialization/src/archive_exception.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_grammar.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_grammar.o" "libs/serialization/src/xml_grammar.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/spirit/home/classic/utility/chset.hpp:15,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/spirit/home/classic/core/primitives/primitives.hpp: In member function ‘typename boost::spirit::classic::parser_result<DerivedT, ScannerT>::type boost::spirit::classic::char_parser<DrivedT>::parse(const ScannerT&) const’:
./boost/spirit/home/classic/core/primitives/primitives.hpp:50:68: warning: typedef ‘result_t’ locally defined but not used [-Wunused-local-typedefs]
   50 |             typedef typename parser_result<self_t, ScannerT>::type result_t;
      |                                                                    ^~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:63,
                 from libs/serialization/src/xml_grammar.cpp:16:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function.hpp:24,
                 from libs/serialization/src/basic_xml_grammar.ipp:35,
                 from libs/serialization/src/xml_grammar.cpp:63:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_grammar.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_iarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_iarchive.o" "libs/serialization/src/xml_iarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_iprimitive.hpp:48,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/xml_iarchive.cpp:20:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/iserializer.hpp:74,
                 from ./boost/archive/detail/interface_iarchive.hpp:22,
                 from ./boost/archive/detail/common_iarchive.hpp:23,
                 from ./boost/archive/basic_xml_iarchive.hpp:23,
                 from ./boost/archive/xml_iarchive.hpp:24,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/xml_iarchive.cpp:20:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/xml_iarchive.hpp:133,
                 from libs/serialization/src/xml_iarchive.cpp:26:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_iarchive.hpp:23,
                 from libs/serialization/src/xml_iarchive.cpp:26:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/spirit/home/classic/utility/chset.hpp:15,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from ./boost/archive/impl/xml_iarchive_impl.ipp:41,
                 from libs/serialization/src/xml_iarchive.cpp:32:
./boost/spirit/home/classic/core/primitives/primitives.hpp: In member function ‘typename boost::spirit::classic::parser_result<DerivedT, ScannerT>::type boost::spirit::classic::char_parser<DrivedT>::parse(const ScannerT&) const’:
./boost/spirit/home/classic/core/primitives/primitives.hpp:50:68: warning: typedef ‘result_t’ locally defined but not used [-Wunused-local-typedefs]
   50 |             typedef typename parser_result<self_t, ScannerT>::type result_t;
      |                                                                    ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_oarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_oarchive.o" "libs/serialization/src/xml_oarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_oprimitive.hpp:52,
                 from ./boost/archive/xml_oarchive.hpp:30,
                 from libs/serialization/src/xml_oarchive.cpp:16:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from /usr/include/c++/9/iomanip:43,
                 from ./boost/archive/basic_text_oprimitive.hpp:27,
                 from ./boost/archive/xml_oarchive.hpp:30,
                 from libs/serialization/src/xml_oarchive.cpp:16:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/xml_oarchive.hpp:22,
                 from libs/serialization/src/xml_oarchive.cpp:16:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/oserializer.hpp:52,
                 from ./boost/archive/detail/interface_oarchive.hpp:23,
                 from ./boost/archive/detail/common_oarchive.hpp:22,
                 from ./boost/archive/basic_xml_oarchive.hpp:21,
                 from ./boost/archive/xml_oarchive.hpp:31,
                 from libs/serialization/src/xml_oarchive.cpp:16:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from ./boost/archive/xml_oarchive.hpp:22,
                 from libs/serialization/src/xml_oarchive.cpp:16:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_archive_exception.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_archive_exception.o" "libs/serialization/src/xml_archive_exception.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/shared_ptr_helper.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/shared_ptr_helper.o" "libs/serialization/src/shared_ptr_helper.cpp"

In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from libs/serialization/src/shared_ptr_helper.cpp:29:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
RmTemps bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_serialization.a(clean)

    rm -f "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_serialization.a" 

gcc.archive bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_serialization.a

    "/usr/bin/ar"  rc "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_serialization.a" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_archive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_iarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_iserializer.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_oarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_oserializer.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_pointer_iserializer.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_pointer_oserializer.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_serializer_map.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_iprimitive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_oprimitive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_xml_archive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/binary_iarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/binary_oarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info_typeid.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/extended_type_info_no_rtti.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/polymorphic_iarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/polymorphic_oarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/stl_port.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_iarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_oarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/void_cast.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/archive_exception.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_grammar.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_iarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_oarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_archive_exception.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/shared_ptr_helper.o"
    "/usr/bin/ranlib" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_serialization.a"

common.copy stage/lib/libboost_serialization.a

    cp "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_serialization.a"  "stage/lib/libboost_serialization.a"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_wiprimitive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_wiprimitive.o" "libs/serialization/src/basic_text_wiprimitive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_iprimitive.hpp:48,
                 from ./boost/archive/impl/basic_text_iprimitive.ipp:24,
                 from libs/serialization/src/basic_text_wiprimitive.cpp:25:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/impl/basic_text_iprimitive.ipp:24,
                 from libs/serialization/src/basic_text_wiprimitive.cpp:25:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/iterator_adaptor.hpp:14,
                 from ./boost/archive/iterators/remove_whitespace.hpp:25,
                 from ./boost/archive/impl/basic_text_iprimitive.ipp:28,
                 from libs/serialization/src/basic_text_wiprimitive.cpp:25:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/archive/impl/basic_text_iprimitive.ipp:31,
                 from libs/serialization/src/basic_text_wiprimitive.cpp:25:
./boost/archive/iterators/transform_width.hpp: In instantiation of ‘boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>::transform_width(const boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>&) [with Base = boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<wchar_t> >, wchar_t>; int BitsOut = 8; int BitsIn = 6; CharType = wchar_t]’:
./boost/archive/impl/basic_text_iprimitive.ipp:90:12:   required from ‘void boost::archive::basic_text_iprimitive<IStream>::load_binary(void*, std::size_t) [with IStream = std::basic_istream<wchar_t>; std::size_t = long unsigned int]’
libs/serialization/src/basic_text_wiprimitive.cpp:30:16:   required from here
./boost/archive/iterators/transform_width.hpp:104:18: warning: ‘boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<wchar_t> >, wchar_t>, 8, 6, wchar_t>::m_remaining_bits’ will be initialized after [-Wreorder]
  104 |     unsigned int m_remaining_bits;
      |                  ^~~~~~~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:101:21: warning:   ‘boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<wchar_t> >, wchar_t>, 8, 6, wchar_t>::base_value_type boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<boost::archive::iterators::remove_whitespace<boost::archive::iterators::istream_iterator<wchar_t> >, wchar_t>, 8, 6, wchar_t>::m_buffer_in’ [-Wreorder]
  101 |     base_value_type m_buffer_in;
      |                     ^~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:119:5: warning:   when initialized here [-Wreorder]
  119 |     transform_width(const transform_width & rhs) :
      |     ^~~~~~~~~~~~~~~
In file included from libs/serialization/src/basic_text_wiprimitive.cpp:25:
./boost/archive/impl/basic_text_iprimitive.ipp:41:10: warning: ‘bool boost::archive::{anonymous}::is_whitespace(CharType) [with CharType = char]’ defined but not used [-Wunused-function]
   41 |     bool is_whitespace(char t){
      |          ^~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_woprimitive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_woprimitive.o" "libs/serialization/src/basic_text_woprimitive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_oprimitive.hpp:52,
                 from ./boost/archive/impl/basic_text_oprimitive.ipp:14,
                 from libs/serialization/src/basic_text_woprimitive.cpp:25:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from /usr/include/c++/9/iomanip:43,
                 from ./boost/archive/basic_text_oprimitive.hpp:27,
                 from ./boost/archive/impl/basic_text_oprimitive.ipp:14,
                 from libs/serialization/src/basic_text_woprimitive.cpp:25:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/mpl/aux_/na_assert.hpp:23,
                 from ./boost/mpl/arg.hpp:25,
                 from ./boost/mpl/placeholders.hpp:24,
                 from ./boost/iterator/iterator_categories.hpp:17,
                 from ./boost/iterator/iterator_adaptor.hpp:14,
                 from ./boost/iterator/transform_iterator.hpp:12,
                 from ./boost/archive/iterators/base64_from_binary.hpp:31,
                 from ./boost/archive/impl/basic_text_oprimitive.ipp:18,
                 from libs/serialization/src/basic_text_woprimitive.cpp:25:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/archive/impl/basic_text_oprimitive.ipp:20,
                 from libs/serialization/src/basic_text_woprimitive.cpp:25:
./boost/archive/iterators/transform_width.hpp: In instantiation of ‘boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>::transform_width(const boost::archive::iterators::transform_width<Base, BitsOut, BitsIn, CharType>&) [with Base = const char*; int BitsOut = 6; int BitsIn = 8; CharType = char]’:
./boost/archive/iterators/base64_from_binary.hpp:101:13:   required from ‘boost::archive::iterators::base64_from_binary<Base, CharType>::base64_from_binary(const boost::archive::iterators::base64_from_binary<Base, CharType>&) [with Base = boost::archive::iterators::transform_width<const char*, 6, 8>; CharType = char]’
./boost/iterator/iterator_adaptor.hpp:276:28:   required from ‘boost::iterator_adaptor<Derived, Base, Value, Traversal, Reference, Difference>::iterator_adaptor(const Base&) [with Derived = boost::archive::iterators::insert_linebreaks<boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<const char*, 6, 8> >, 76, const char>; Base = boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<const char*, 6, 8> >; Value = const char; Traversal = boost::single_pass_traversal_tag; Reference = const char; Difference = boost::use_default]’
./boost/archive/iterators/insert_linebreaks.hpp:88:18:   required from ‘boost::archive::iterators::insert_linebreaks<Base, N, CharType>::insert_linebreaks(T) [with T = const char*; Base = boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<const char*, 6, 8> >; int N = 76; CharType = const char]’
./boost/archive/impl/basic_text_oprimitive.ipp:61:9:   required from ‘void boost::archive::basic_text_oprimitive<OStream>::save_binary(const void*, std::size_t) [with OStream = std::basic_ostream<wchar_t>; std::size_t = long unsigned int]’
libs/serialization/src/basic_text_woprimitive.cpp:30:16:   required from here
./boost/archive/iterators/transform_width.hpp:104:18: warning: ‘boost::archive::iterators::transform_width<const char*, 6, 8>::m_remaining_bits’ will be initialized after [-Wreorder]
  104 |     unsigned int m_remaining_bits;
      |                  ^~~~~~~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:101:21: warning:   ‘boost::archive::iterators::transform_width<const char*, 6, 8>::base_value_type boost::archive::iterators::transform_width<const char*, 6, 8>::m_buffer_in’ [-Wreorder]
  101 |     base_value_type m_buffer_in;
      |                     ^~~~~~~~~~~
./boost/archive/iterators/transform_width.hpp:119:5: warning:   when initialized here [-Wreorder]
  119 |     transform_width(const transform_width & rhs) :
      |     ^~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_wiarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_wiarchive.o" "libs/serialization/src/text_wiarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_iprimitive.hpp:48,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/text_wiarchive.cpp:11:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/iserializer.hpp:74,
                 from ./boost/archive/detail/interface_iarchive.hpp:22,
                 from ./boost/archive/detail/common_iarchive.hpp:23,
                 from ./boost/archive/basic_text_iarchive.hpp:31,
                 from ./boost/archive/text_wiarchive.hpp:28,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/text_wiarchive.cpp:11:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/text_wiarchive.hpp:120,
                 from libs/serialization/src/text_wiarchive.cpp:18:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/text_wiarchive.hpp:27,
                 from libs/serialization/src/text_wiarchive.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_woarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_woarchive.o" "libs/serialization/src/text_woarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_oprimitive.hpp:52,
                 from ./boost/archive/text_woarchive.hpp:35,
                 from libs/serialization/src/text_woarchive.cpp:17:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from /usr/include/c++/9/iomanip:43,
                 from ./boost/archive/basic_text_oprimitive.hpp:27,
                 from ./boost/archive/text_woarchive.hpp:35,
                 from libs/serialization/src/text_woarchive.cpp:17:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/text_woarchive.cpp:11:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/oserializer.hpp:52,
                 from ./boost/archive/detail/interface_oarchive.hpp:23,
                 from ./boost/archive/detail/common_oarchive.hpp:22,
                 from ./boost/archive/basic_text_oarchive.hpp:32,
                 from ./boost/archive/text_woarchive.hpp:36,
                 from libs/serialization/src/text_woarchive.cpp:17:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/text_woarchive.cpp:11:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o" "libs/serialization/src/utf8_codecvt_facet.cpp"

gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_wgrammar.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_wgrammar.o" "libs/serialization/src/xml_wgrammar.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/spirit/home/classic/utility/chset.hpp:13,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/spirit/home/classic/utility/chset.hpp:15,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/spirit/home/classic/core/primitives/primitives.hpp: In member function ‘typename boost::spirit::classic::parser_result<DerivedT, ScannerT>::type boost::spirit::classic::char_parser<DrivedT>::parse(const ScannerT&) const’:
./boost/spirit/home/classic/core/primitives/primitives.hpp:50:68: warning: typedef ‘result_t’ locally defined but not used [-Wunused-local-typedefs]
   50 |             typedef typename parser_result<self_t, ScannerT>::type result_t;
      |                                                                    ^~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:63,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/function/detail/prologue.hpp:18,
                 from ./boost/function.hpp:24,
                 from libs/serialization/src/basic_xml_grammar.ipp:35,
                 from libs/serialization/src/xml_wgrammar.cpp:146:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/smart_ptr/scoped_ptr.hpp:21,
                 from ./boost/scoped_ptr.hpp:14,
                 from ./boost/spirit/home/classic/core/non_terminal/rule.hpp:31,
                 from ./boost/spirit/include/classic_rule.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:58,
                 from libs/serialization/src/xml_wgrammar.cpp:18:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_wiarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_wiarchive.o" "libs/serialization/src/xml_wiarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_iprimitive.hpp:48,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/xml_wiarchive.cpp:11:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/iserializer.hpp:74,
                 from ./boost/archive/detail/interface_iarchive.hpp:22,
                 from ./boost/archive/detail/common_iarchive.hpp:23,
                 from ./boost/archive/basic_xml_iarchive.hpp:23,
                 from ./boost/archive/xml_wiarchive.hpp:29,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/xml_wiarchive.cpp:11:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/detail/shared_count.hpp: At global scope:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/archive/shared_ptr_helper.hpp:25,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/detail/shared_ptr_132.hpp:29,
                 from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/serialization/detail/shared_count_132.hpp: At global scope:
./boost/serialization/detail/shared_count_132.hpp:371:32: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  371 |     explicit shared_count(std::auto_ptr<Y> & r): pi_(
      |                                ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/serialization/detail/shared_ptr_132.hpp:202:30: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  202 |     explicit shared_ptr(std::auto_ptr<Y> & r): px(r.get()), pn()
      |                              ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/serialization/shared_ptr_132.hpp:35,
                 from ./boost/archive/shared_ptr_helper.hpp:29,
                 from ./boost/archive/xml_wiarchive.hpp:138,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
./boost/serialization/detail/shared_ptr_132.hpp:226:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  226 |     shared_ptr & operator=(std::auto_ptr<Y> & r)
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from ./boost/archive/basic_text_iprimitive.hpp:28,
                 from ./boost/archive/xml_wiarchive.hpp:28,
                 from libs/serialization/src/xml_wiarchive.cpp:31:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/spirit/home/classic/utility/chset.hpp:15,
                 from ./boost/spirit/include/classic_chset.hpp:11,
                 from ./boost/archive/impl/basic_xml_grammar.hpp:59,
                 from ./boost/archive/impl/xml_wiarchive_impl.ipp:45,
                 from libs/serialization/src/xml_wiarchive.cpp:37:
./boost/spirit/home/classic/core/primitives/primitives.hpp: In member function ‘typename boost::spirit::classic::parser_result<DerivedT, ScannerT>::type boost::spirit::classic::char_parser<DrivedT>::parse(const ScannerT&) const’:
./boost/spirit/home/classic/core/primitives/primitives.hpp:50:68: warning: typedef ‘result_t’ locally defined but not used [-Wunused-local-typedefs]
   50 |             typedef typename parser_result<self_t, ScannerT>::type result_t;
      |                                                                    ^~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_woarchive.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_woarchive.o" "libs/serialization/src/xml_woarchive.cpp"

In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/archive/basic_text_oprimitive.hpp:52,
                 from ./boost/archive/xml_woarchive.hpp:34,
                 from libs/serialization/src/xml_woarchive.cpp:17:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/bits/locale_conv.h:41,
                 from /usr/include/c++/9/locale:43,
                 from /usr/include/c++/9/iomanip:43,
                 from ./boost/archive/basic_text_oprimitive.hpp:27,
                 from ./boost/archive/xml_woarchive.hpp:34,
                 from libs/serialization/src/xml_woarchive.cpp:17:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/xml_woarchive.cpp:11:
./boost/serialization/extended_type_info_typeid.hpp: In member function ‘const boost::serialization::extended_type_info* boost::serialization::extended_type_info_typeid<T>::get_derived_extended_type_info(const T&) const’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE102’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/serialization/extended_type_info_typeid.hpp:102:9: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  102 |         BOOST_STATIC_WARNING(boost::is_polymorphic< T >::value);
      |         ^~~~~~~~~~~~~~~~~~~~
In file included from ./boost/serialization/version.hpp:20,
                 from ./boost/archive/detail/oserializer.hpp:52,
                 from ./boost/archive/detail/interface_oarchive.hpp:23,
                 from ./boost/archive/detail/common_oarchive.hpp:22,
                 from ./boost/archive/basic_xml_oarchive.hpp:21,
                 from ./boost/archive/xml_woarchive.hpp:35,
                 from libs/serialization/src/xml_woarchive.cpp:17:
./boost/mpl/assert.hpp: At global scope:
./boost/mpl/assert.hpp:187:21: warning: unnecessary parentheses in declaration of ‘assert_arg’ [-Wparentheses]
  187 | failed ************ (Pred::************
      |                     ^
./boost/mpl/assert.hpp:192:21: warning: unnecessary parentheses in declaration of ‘assert_not_arg’ [-Wparentheses]
  192 | failed ************ (boost::mpl::not_<Pred>::************
      |                     ^
In file included from ./boost/config.hpp:57,
                 from libs/serialization/src/xml_woarchive.cpp:11:
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_object_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE98’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:98:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
   98 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_level()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE137’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:137:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  137 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp: In function ‘void boost::archive::detail::check_pointer_tracking()’:
./boost/serialization/static_warning.hpp:104:18: warning: typedef ‘STATIC_WARNING_LINE148’ locally defined but not used [-Wunused-local-typedefs]
  104 |     > BOOST_JOIN(STATIC_WARNING_LINE, L);
      |                  ^~~~~~~~~~~~~~~~~~~
./boost/serialization/static_warning.hpp:106:33: note: in expansion of macro ‘BOOST_SERIALIZATION_BSW’
  106 | #define BOOST_STATIC_WARNING(B) BOOST_SERIALIZATION_BSW(B, __LINE__)
      |                                 ^~~~~~~~~~~~~~~~~~~~~~~
./boost/archive/detail/check.hpp:148:5: note: in expansion of macro ‘BOOST_STATIC_WARNING’
  148 |     BOOST_STATIC_WARNING(typex::value);
      |     ^~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/codecvt_null.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pthread  -DBOOST_ALL_NO_LIB=1 -DNDEBUG  -I"." -c -o "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/codecvt_null.o" "libs/serialization/src/codecvt_null.cpp"

RmTemps bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_wserialization.a(clean)

    rm -f "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_wserialization.a" 

gcc.archive bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_wserialization.a

    "/usr/bin/ar"  rc "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_wserialization.a" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_wiprimitive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/basic_text_woprimitive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_wiarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/text_woarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/utf8_codecvt_facet.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_wgrammar.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_wiarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/xml_woarchive.o" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/codecvt_null.o"
    "/usr/bin/ranlib" "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_wserialization.a"

common.copy stage/lib/libboost_wserialization.a

    cp "bin.v2/libs/serialization/build/gcc-9/release/link-static/threading-multi/libboost_wserialization.a"  "stage/lib/libboost_wserialization.a"

gcc.compile.c++ bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/pthread/thread.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pedantic -pthread -Wextra -Wno-long-long -Wno-variadic-macros -Wunused-function -pedantic -DBOOST_ALL_NO_LIB=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DBOOST_THREAD_BUILD_LIB=1 -DBOOST_THREAD_DONT_USE_CHRONO -DBOOST_THREAD_POSIX -DNDEBUG  -I"." -c -o "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/pthread/thread.o" "libs/thread/src/pthread/thread.cpp"

In file included from ./boost/smart_ptr/shared_ptr.hpp:32,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/detail/shared_count.hpp:323:33: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  323 |     explicit shared_count( std::auto_ptr<Y> & r ): pi_( new sp_counted_impl_p<Y>( r.get() ) )
      |                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:247:65: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  247 | template< class T, class R > struct sp_enable_if_auto_ptr< std::auto_ptr< T >, R >
      |                                                                 ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:446:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  446 |     explicit shared_ptr( std::auto_ptr<Y> & r ): px(r.get()), pn()
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:459:22: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  459 |     shared_ptr( std::auto_ptr<Y> && r ): px(r.get()), pn()
      |                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:525:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  525 |     shared_ptr & operator=( std::auto_ptr<Y> & r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/shared_ptr.hpp:534:34: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  534 |     shared_ptr & operator=( std::auto_ptr<Y> && r )
      |                                  ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/smart_ptr/shared_ptr.hpp: In member function ‘boost::shared_ptr<T>& boost::shared_ptr<T>::operator=(std::auto_ptr<_Up>&&)’:
./boost/smart_ptr/shared_ptr.hpp:536:38: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
  536 |         this_type( static_cast< std::auto_ptr<Y> && >( r ) ).swap( *this );
      |                                      ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/bind/bind.hpp:26,
                 from ./boost/bind.hpp:22,
                 from ./boost/thread/detail/thread.hpp:29,
                 from ./boost/thread/thread_only.hpp:22,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/get_pointer.hpp: At global scope:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/bind/bind.hpp:29,
                 from ./boost/bind.hpp:22,
                 from ./boost/thread/detail/thread.hpp:29,
                 from ./boost/thread/thread_only.hpp:22,
                 from libs/thread/src/pthread/thread.cpp:11:
./boost/bind/arg.hpp: In constructor ‘boost::arg<I>::arg(const T&)’:
./boost/bind/arg.hpp:37:22: warning: typedef ‘T_must_be_placeholder’ locally defined but not used [-Wunused-local-typedefs]
   37 |         typedef char T_must_be_placeholder[ I == is_placeholder<T>::value? 1: -1 ];
      |                      ^~~~~~~~~~~~~~~~~~~~~
In file included from ./boost/scoped_ptr.hpp:14,
                 from ./boost/thread/future.hpp:30,
                 from libs/thread/src/pthread/thread.cpp:19:
./boost/smart_ptr/scoped_ptr.hpp: At global scope:
./boost/smart_ptr/scoped_ptr.hpp:68:31: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   68 |     explicit scoped_ptr( std::auto_ptr<T> p ) BOOST_NOEXCEPT : px( p.release() )
      |                               ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/smart_ptr/shared_ptr.hpp:27,
                 from ./boost/shared_ptr.hpp:17,
                 from ./boost/date_time/time_clock.hpp:17,
                 from ./boost/thread/thread_time.hpp:9,
                 from ./boost/thread/lock_types.hpp:18,
                 from ./boost/thread/pthread/thread_data.hpp:12,
                 from ./boost/thread/thread_only.hpp:17,
                 from libs/thread/src/pthread/thread.cpp:11:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
gcc.compile.c++ bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/pthread/once.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pedantic -pthread -Wextra -Wno-long-long -Wno-variadic-macros -Wunused-function -pedantic -DBOOST_ALL_NO_LIB=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DBOOST_THREAD_BUILD_LIB=1 -DBOOST_THREAD_DONT_USE_CHRONO -DBOOST_THREAD_POSIX -DNDEBUG  -I"." -c -o "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/pthread/once.o" "libs/thread/src/pthread/once.cpp"

In file included from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/bind/bind.hpp:26,
                 from ./boost/bind.hpp:22,
                 from ./boost/thread/pthread/once_atomic.hpp:19,
                 from ./boost/thread/once.hpp:20,
                 from libs/thread/src/pthread/./once_atomic.cpp:9,
                 from libs/thread/src/pthread/once.cpp:8:
./boost/get_pointer.hpp:27:40: warning: ‘template<class> class std::auto_ptr’ is deprecated [-Wdeprecated-declarations]
   27 | template<class T> T * get_pointer(std::auto_ptr<T> const& p)
      |                                        ^~~~~~~~
In file included from /usr/include/c++/9/memory:80,
                 from ./boost/config/no_tr1/memory.hpp:21,
                 from ./boost/get_pointer.hpp:14,
                 from ./boost/bind/mem_fn.hpp:25,
                 from ./boost/mem_fn.hpp:22,
                 from ./boost/bind/bind.hpp:26,
                 from ./boost/bind.hpp:22,
                 from ./boost/thread/pthread/once_atomic.hpp:19,
                 from ./boost/thread/once.hpp:20,
                 from libs/thread/src/pthread/./once_atomic.cpp:9,
                 from libs/thread/src/pthread/once.cpp:8:
/usr/include/c++/9/bits/unique_ptr.h:53:28: note: declared here
   53 |   template<typename> class auto_ptr;
      |                            ^~~~~~~~
In file included from ./boost/bind/bind.hpp:29,
                 from ./boost/bind.hpp:22,
                 from ./boost/thread/pthread/once_atomic.hpp:19,
                 from ./boost/thread/once.hpp:20,
                 from libs/thread/src/pthread/./once_atomic.cpp:9,
                 from libs/thread/src/pthread/once.cpp:8:
./boost/bind/arg.hpp: In constructor ‘boost::arg<I>::arg(const T&)’:
./boost/bind/arg.hpp:37:22: warning: typedef ‘T_must_be_placeholder’ locally defined but not used [-Wunused-local-typedefs]
   37 |         typedef char T_must_be_placeholder[ I == is_placeholder<T>::value? 1: -1 ];
      |                      ^~~~~~~~~~~~~~~~~~~~~
gcc.compile.c++ bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/future.o

    "g++"  -ftemplate-depth-128 -O3 -finline-functions -Wno-inline -Wall -pedantic -pthread -Wextra -Wno-long-long -Wno-variadic-macros -Wunused-function -pedantic -DBOOST_ALL_NO_LIB=1 -DBOOST_SYSTEM_STATIC_LINK=1 -DBOOST_THREAD_BUILD_LIB=1 -DBOOST_THREAD_DONT_USE_CHRONO -DBOOST_THREAD_POSIX -DNDEBUG  -I"." -c -o "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/future.o" "libs/thread/src/future.cpp"

RmTemps bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/libboost_thread.a(clean)

    rm -f "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/libboost_thread.a" 

gcc.archive bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/libboost_thread.a

    "/usr/bin/ar"  rc "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/libboost_thread.a" "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/pthread/thread.o" "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/pthread/once.o" "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/future.o"
    "/usr/bin/ranlib" "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/libboost_thread.a"

common.copy stage/lib/libboost_thread.a

    cp "bin.v2/libs/thread/build/gcc-9/release/link-static/threading-multi/libboost_thread.a"  "stage/lib/libboost_thread.a"

...updated 92 targets...
