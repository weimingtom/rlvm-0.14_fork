http://guichan.sourceforge.net/oldsite/imagefontcollection.shtml

ImageFont collection

Here is a collection of fonts for the ImageFont class of Guichan. Some of the fonts have been 
submited by users of Guichan. If you have a font which you think should be here, please send us an 
email an we will happily add it.

fixedfont
Font from the examples directory in the Guichan source.

fixedfont_big
Font from the examples directory in the Guichan source.

rpgfont
Font from the FF demo.

rpgfont2
Font from the FF demo.

techyfontbig
Font from the FPS demo.

techyfontbig2
Font from the FPS demo.

techyfontblack
Font from the FPS demo.

techyfontwhite
Font from the FPS demo.

thinsans
Submitted by Terin.

papyrus_32
Submitted by holomorph.

rpgfont_thinner_noshadow
Submitted by Thorbj?rn Lindeijer.

