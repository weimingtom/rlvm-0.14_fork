package com.iteye.weimingtom.guichan.gce.widget;

import com.iteye.weimingtom.guichan.basic.Color;
import com.iteye.weimingtom.guichan.basic.GuichanException;
import com.iteye.weimingtom.guichan.basic.Rectangle;
import com.iteye.weimingtom.guichan.gce.EditorGui;
import com.iteye.weimingtom.guichan.platform.Graphics;
import com.iteye.weimingtom.guichan.widget.RadioButton;

public class GceRadioButtonEdit extends RadioButton {
	public GceRadioButtonEdit() throws GuichanException {
		super();
	}

	public GceRadioButtonEdit(String caption, String group)
			throws GuichanException {
		super(caption, group);
	}

	public GceRadioButtonEdit(String caption, String group, boolean selected)
			throws GuichanException {
		super(caption, group, selected);
	}

	@Override
	public void draw(Graphics g) throws GuichanException {
		super.draw(g);
	    if (EditorGui.currentWidget == this) {
	        g.setColor(new Color(255, 0, 0, 128));        
	        g.fillRectangle(new Rectangle(0, 0, 12, 12));
	        int w = getWidth();
	        int h = getHeight();
	        g.fillRectangle(new Rectangle(w - 12, h - 12, w, h));
	    }
	}
}
