package com.iteye.weimingtom.guichan.gce.listener;

import com.iteye.weimingtom.guichan.basic.GuichanException;

public interface GceFileDialogCallback {
	public void callback(String arg) throws GuichanException;
}
