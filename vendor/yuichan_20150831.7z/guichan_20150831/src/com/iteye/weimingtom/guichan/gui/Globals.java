package com.iteye.weimingtom.guichan.gui;

import com.iteye.weimingtom.guichan.platform.AppLauncher;

public class Globals {
    public static Gui gui;
    public static AppLauncher app;
}
