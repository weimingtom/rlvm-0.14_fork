package com.iteye.weimingtom.guichan.basic;

public class GuichanException extends Exception {
	private static final long serialVersionUID = 1L;

	public GuichanException() {
	
	}

	public GuichanException(String arg0) {
		super(arg0);
	}

	public GuichanException(Throwable arg0) {
		super(arg0);
	}

	public GuichanException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
}
