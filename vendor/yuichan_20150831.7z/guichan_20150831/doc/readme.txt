D:\android_rtmp\ffmpeg\msys\home\Administrator\guichan
F:\pan2\android_rtmp\ffmpeg\msys\home\Administrator\guichan
D:\_备份代码_4\20150801

BasicContainer::drawChildren
Window::draw

确保xml去除textbox的width和height属性后仍能保持与scrollarea同大小

* tab key
* redraw lock
* textbox


D:\_2015新年\20150313\gce-guichan-0.8

TODO:
* 检查静态变量
* 检查equals
* 检查重复get
* 栈上构造函数如Rect
* 析构函数
* 手工解码xml和json
* GCE加载错误文件时行为不正常
* 动态修改窗口大小
