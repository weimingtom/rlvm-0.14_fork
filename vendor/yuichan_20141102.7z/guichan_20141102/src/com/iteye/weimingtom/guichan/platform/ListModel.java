package com.iteye.weimingtom.guichan.platform;

public abstract class ListModel {
    public abstract int getNumberOfElements();
    
    public abstract String getElementAt(int i);
}
