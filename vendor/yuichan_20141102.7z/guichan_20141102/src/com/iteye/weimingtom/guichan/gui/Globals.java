package com.iteye.weimingtom.guichan.gui;

public class Globals {
    public static Gui gui;
}
