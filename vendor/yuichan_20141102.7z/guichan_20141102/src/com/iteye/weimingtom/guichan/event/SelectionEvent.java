package com.iteye.weimingtom.guichan.event;

import com.iteye.weimingtom.guichan.gui.Widget;

public class SelectionEvent extends Event {

	public SelectionEvent(Widget source) {
		super(source);
	}

}
